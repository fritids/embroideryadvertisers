<?php
/**
 * Changing things here breaks things!
 */

define('BROADSTREET_PARTNER_NAME', 'AJdGSolutions');
define('BROADSTRET_PARTNER_PLUGIN', '/adrotate');
define('BROADSTREET_VENDOR_PATH', '/library/broadstreet');
define('BROADSTREET_AD_TAG_SELECTOR', '[name="adrotate_bannercode"]');
define('BROADSTREET_DEBUG', false);
?>