<?php include('header.php'); ?>
	</head>
	<body id="media-upload">
		<div id="wpwrap">
<?php echo do_shortcode("[mailpress_form id='" . $form->id . "']"); ?>
		</div>
	</body>
</html>