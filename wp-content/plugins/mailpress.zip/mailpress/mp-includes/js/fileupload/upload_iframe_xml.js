jQuery(document).ready( function() {
	var xml = jQuery('pre').html();
	parent.mp_fileupload.loaded(uploadxmlL10n.$draft_id, uploadxmlL10n.file, xml, uploadxmlL10n.id);
});