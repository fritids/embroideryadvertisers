=== mp-content folders ===

* add-ons
	- contains all mailpress add-ons

* advanced
	- see advanced/readme.txt

* languages
	- .pot .mo .po language files

* themes
	- plaintext : default mailpress theme folder for plaintext mails
	- mailpress theme folders

* xtras
	- mp_batch_send : sample for external scheduling
	- mp_bounce_handling : sample for external scheduling
	- mp_tracking_rewrite_url : .htaccess sample for add-on MailPress_tracking_rewrite_url

	- category-xx.php  : category template to copy inside your WordPress theme folder (see http://blog.mailpress.org/tutorials). 
	- pt_MailPress.php : page     template to copy inside your WordPress theme folder (see http://blog.mailpress.org/tutorials). 

=== miscellaneous ===

If you want to rename and/or place the 'mp-content' folder in 'mailpress' folder or its parent directory,
see mailpress/mailpress-config-sample.php.

