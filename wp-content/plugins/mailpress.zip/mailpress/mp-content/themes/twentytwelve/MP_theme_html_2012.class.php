<?php
class MP_theme_html_2012 extends MP_theme_html_
{
	const HEADER_IMAGE_WIDTH = 760;
	const HEADER_IMAGE_HEIGHT = 198;

	var $style = 'style="font-size:12px;color:#777;font-style:italic;"';
}
new MP_theme_html_2012();