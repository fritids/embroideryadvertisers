<?php
/*
Template Name: form_destinataire
Subject: [<?php bloginfo('name');?>] Mail issu de formulaire
*/

$this->build->_the_title = "Mail issu de formulaire";

$this->get_template_part('_mail');