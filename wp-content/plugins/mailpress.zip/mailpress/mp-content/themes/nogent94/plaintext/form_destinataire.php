<?php
/*
Template Name: form_destinataire
*/

$this->build->_the_title = "Mail issu de formulaire";

$this->get_template_part('_mail');