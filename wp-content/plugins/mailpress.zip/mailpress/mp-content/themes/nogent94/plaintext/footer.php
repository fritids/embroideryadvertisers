﻿
							ce mail est envoyé avec MailPress

<?php if (isset($this->args->viewhtml)) : ?>View [{{viewhtml}}]<?php endif; ?>

<?php if (isset($this->args->unsubscribe)) : ?>Unsubscribe [{{unsubscribe}}]<?php endif; ?>
