<?php
$this->get_header();
$this->get_template_part('_loop');
$this->get_footer();
