<?php
/*
Template Name: monthlycat
*/

$this->get_template_part('_post');