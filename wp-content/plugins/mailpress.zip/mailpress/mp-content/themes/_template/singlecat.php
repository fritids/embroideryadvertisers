<?php
/*
Template Name: singlecat
*/

$this->get_template_part('_post');