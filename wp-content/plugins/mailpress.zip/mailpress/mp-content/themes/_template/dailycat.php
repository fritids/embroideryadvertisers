<?php
/*
Template Name: dailycat
*/

$this->get_template_part('_post');