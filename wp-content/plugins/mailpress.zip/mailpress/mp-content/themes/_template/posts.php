<?php
/*
Template Name: posts
*/

$this->get_template_part('_post');