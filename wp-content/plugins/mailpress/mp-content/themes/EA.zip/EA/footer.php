<!-- start footer -->
<div><center>
Like what we are doing? Take a moment and give us some feedback, simply click on the link to go to the survey: <a href="http://embroideryadvertisers.com/survey/">http://embroideryadvertisers.com/survey/</a><br>

<h3>This newsletter sponsored by:<br><?php echo do_shortcode('[adrotate group="3"]'); ?></h3>
If you would like to sponsor this newsletter please check out our <a href="http://embroideryadvertisers.com/advertise-with-us/#newsletter">advertising page</a>.

<center></div>
				</div>
				
<?php //$this->get_sidebar(); ?>
			</div>
			<div style='clear:both;'></div>
				<div <?php $this->classes('nopmb fltd'); ?>>
				Embroidery Advertisers
				</div>

				<div <?php $this->classes('frtd');?>>
				Helping Build Your Business, One Stitch at a Time!
				</div>
            
		</div>
		</div>
        <?php if (isset($this->args->unsubscribe)) { ?>
			<div <?php $this->classes('mail_link'); ?>>
				Click <a href="http://embroideryadvertisers.com/actions/?action=mailunsubscribe&email={{toemail}}">here</a> to unsubscribe from these emails.
			</div>
<?php } ?>
	</body>
</html>
