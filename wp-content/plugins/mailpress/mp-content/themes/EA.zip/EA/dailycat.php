<?php
/*
Template Name: dailycat
Subject: Embroidery Advertisers Daily News for <? date_default_timezone_set('America/Denver'); echo date('F j, Y'); ?>


*/

$this->get_template_part('_post');