<?php
class MP_Dashboard_widgets extends MP_options_
{
	var $path = 'dashboard/widgets';
}