<?php
class MP_Tracking_recipient_domain extends MP_tracking_recipient_
{
	public $id = 'domain';
}
new MP_Tracking_recipient_domain (__('domain', MP_TXTDOM));