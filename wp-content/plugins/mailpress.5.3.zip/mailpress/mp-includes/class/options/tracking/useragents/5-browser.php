<?php
class MP_Tracking_useragent_browser extends MP_tracking_useragent_
{
	public $id = 'browser';
}
new MP_Tracking_useragent_browser(__('browser', MP_TXTDOM));