<?php
class MP_Tracking_useragent_os extends MP_tracking_useragent_
{
	public $id = 'os';
}
new MP_Tracking_useragent_os(__('os', MP_TXTDOM));