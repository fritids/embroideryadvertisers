<?php
class MP_Tracking_useragent_device extends MP_tracking_useragent_
{
	public $id = 'device';
}
new MP_Tracking_useragent_device(__('device', MP_TXTDOM));