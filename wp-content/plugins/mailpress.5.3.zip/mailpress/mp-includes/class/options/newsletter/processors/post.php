<?php
class MP_Newsletter_processor_post extends MP_newsletter_processor_post_
{
	public $id = 'post';
}
new MP_Newsletter_processor_post(__('Post', MP_TXTDOM));