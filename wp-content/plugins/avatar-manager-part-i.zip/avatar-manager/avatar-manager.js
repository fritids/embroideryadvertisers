jQuery( document ).ready( function() {
	jQuery( '#your-profile' ).attr( 'enctype', 'multipart/form-data' );
} );
