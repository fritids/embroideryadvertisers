<?php
/*
Plugin Name: WPMS db Cleaner
Plugin URI: http://slangji.wordpress.com/wpms-mu-plugins-clnr/
Description: Clean orphaned wp_options db maked from outdated and unsupported /mu-plugins/ installation.
Version: 2013.0725.5555
Author: sLa NGjI's
Author URI: http://slangji.wordpress.com/
Requires at least: 2.6
Tested up to: 3.6
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
Indentation: GNU style coding standard
Indentation URI: http://www.gnu.org/prep/standards/standards.html
 */

	/**
	 * @package WPMS db Cleaner
	 * @subpackage WordPress PlugIn
	 * @description Clean orphaned wp_options db maked from outdated and unsupported /mu-plugins/ installation.
	 * @since 2.6.0
	 * @tested 3.6.0
	 * @version 2013.0725.5555
	 * @status STABLE release
	 * @author sLa NGjI's
	 * @license GPLv2 or later
	 * @indentation GNU style coding standard
	 */

	add_action('admin_notices', create_function( '', "echo '<div class=\"error\"><p>".__('For cleaning orphaned wp_option db maked from outdated and unsupported /mu-plugins/ installation deactivate and delete this plugin.!', 'wpms_mu_plugins_clnr') ."</p></div>';" ) );

	function wpms_mu_plugins_clnr()
		{
			delete_option( wp_missed_schedule );
		}
	register_deactivation_hook( __FILE__, 'wpms_mu_plugins_clnr', 0 );
?>